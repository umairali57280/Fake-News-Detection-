"""
evaluate.py — Model Evaluation & Visualization
================================================
Fake News Detection System
Authors: Hussain Rehan, Minhaj Zaib Khan, Arsalan Ahmed Khan
Subject: Machine Learning (BSCS F23 / 240ML)
Instructor: Dr. Abid Ali — PAF-IAST Mang Haripur

Generates:
  • Per-model confusion matrices
  • Combined ROC curve
  • Grouped bar chart (Accuracy / F1 / AUC-ROC)
  • results_summary.csv
  • False-positive / false-negative analysis
"""

import os
import sys
import random
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, roc_curve,
                             confusion_matrix, classification_report)

warnings.filterwarnings('ignore')

# ── Reproducibility ──────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
CM_DIR = os.path.join(OUTPUT_DIR, "confusion_matrices")
ROC_DIR = os.path.join(OUTPUT_DIR, "roc_curves")

for d in [OUTPUT_DIR, CM_DIR, ROC_DIR]:
    os.makedirs(d, exist_ok=True)

sys.path.insert(0, BASE_DIR)


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  COMPUTE METRICS
# ═══════════════════════════════════════════════════════════════════════════════

def compute_metrics(model, X_test, y_test, model_name: str) -> dict:
    """
    Compute all classification metrics for a single model.

    Parameters
    ----------
    model : estimator
        Fitted scikit-learn classifier.
    X_test : sparse matrix
        Test-set TF-IDF features.
    y_test : array-like
        True test labels.
    model_name : str
        Human-readable model name.

    Returns
    -------
    dict
        Keys: Model, Accuracy, Precision, Recall, F1_Score, AUC_ROC,
        y_pred, y_proba.
    """
    y_pred = model.predict(X_test)

    # Probability / decision-function scores for AUC
    if hasattr(model, 'predict_proba'):
        y_proba = model.predict_proba(X_test)[:, 1]
    elif hasattr(model, 'decision_function'):
        df_scores = model.decision_function(X_test)
        y_proba = 1 / (1 + np.exp(-df_scores))  # sigmoid
    else:
        y_proba = y_pred.astype(float)

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average='macro')
    rec = recall_score(y_test, y_pred, average='macro')
    f1 = f1_score(y_test, y_pred, average='macro')
    auc = roc_auc_score(y_test, y_proba)

    return {
        'Model': model_name,
        'Accuracy': round(acc, 4),
        'Precision': round(prec, 4),
        'Recall': round(rec, 4),
        'F1_Score': round(f1, 4),
        'AUC_ROC': round(auc, 4),
        'y_pred': y_pred,
        'y_proba': y_proba,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  CONFUSION MATRIX PLOT
# ═══════════════════════════════════════════════════════════════════════════════

def plot_confusion_matrix(y_test, y_pred, model_name: str, save_dir: str = CM_DIR):
    """
    Plot and save a seaborn heatmap confusion matrix.

    Parameters
    ----------
    y_test : array-like
        True labels.
    y_pred : array-like
        Predicted labels.
    model_name : str
        Model name (used in title & filename).
    save_dir : str
        Directory to save the PNG.
    """
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['Fake', 'Real'],
                yticklabels=['Fake', 'Real'], ax=ax,
                linewidths=1, linecolor='white',
                annot_kws={'size': 14, 'weight': 'bold'})
    ax.set_xlabel('Predicted', fontsize=13, fontweight='bold')
    ax.set_ylabel('Actual', fontsize=13, fontweight='bold')
    ax.set_title(f'{model_name.replace("_", " ")} — Confusion Matrix',
                 fontsize=14, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(save_dir, f"{model_name}_cm.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  [SAVED] Confusion matrix → {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  ROC CURVE (all models)
# ═══════════════════════════════════════════════════════════════════════════════

def plot_roc_curves(all_metrics: list, y_test, save_dir: str = ROC_DIR):
    """
    Plot ROC curves for all models on a single figure.

    Parameters
    ----------
    all_metrics : list of dict
        Each dict must contain ``Model``, ``y_proba``, and ``AUC_ROC``.
    y_test : array-like
        True test labels.
    save_dir : str
        Directory to save the PNG.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    colors = ['#E74C3C', '#3498DB', '#2ECC71', '#F39C12', '#9B59B6']

    for i, m in enumerate(all_metrics):
        fpr, tpr, _ = roc_curve(y_test, m['y_proba'])
        ax.plot(fpr, tpr, color=colors[i % len(colors)], linewidth=2,
                label=f"{m['Model'].replace('_', ' ')} (AUC = {m['AUC_ROC']:.4f})")

    ax.plot([0, 1], [0, 1], 'k--', linewidth=1, alpha=0.5)
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title('ROC Curves — All Models', fontsize=14, fontweight='bold')
    ax.legend(loc='lower right', fontsize=10)
    ax.grid(alpha=0.3)
    plt.tight_layout()

    path = os.path.join(save_dir, "all_models_roc.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"  [SAVED] ROC curves → {path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  MODEL COMPARISON CHART
# ═══════════════════════════════════════════════════════════════════════════════

def plot_model_comparison(results_df: pd.DataFrame, save_path: str = None):
    """
    Grouped bar chart comparing Accuracy, F1-Score, and AUC-ROC for all models.

    Parameters
    ----------
    results_df : pd.DataFrame
        DataFrame with columns Model, Accuracy, F1_Score, AUC_ROC.
    save_path : str, optional
        File path to save the chart.
    """
    if save_path is None:
        save_path = os.path.join(OUTPUT_DIR, "model_comparison.png")

    models = results_df['Model'].tolist()
    x = np.arange(len(models))
    width = 0.25

    fig, ax = plt.subplots(figsize=(12, 6))

    bars_acc = ax.bar(x - width, results_df['Accuracy'], width,
                      label='Accuracy', color='#3498DB', edgecolor='white')
    bars_f1 = ax.bar(x, results_df['F1_Score'], width,
                     label='F1-Score', color='#2ECC71', edgecolor='white')
    bars_auc = ax.bar(x + width, results_df['AUC_ROC'], width,
                      label='AUC-ROC', color='#F39C12', edgecolor='white')

    # Value labels
    for bars in [bars_acc, bars_f1, bars_auc]:
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2, h + 0.003,
                    f'{h:.3f}', ha='center', va='bottom', fontsize=8,
                    fontweight='bold')

    ax.set_ylabel('Score', fontsize=12)
    ax.set_title('Model Comparison — Accuracy / F1 / AUC-ROC',
                 fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace('_', ' ') for m in models],
                       fontsize=10, rotation=15, ha='right')
    ax.legend(fontsize=11)
    ax.set_ylim(0, 1.10)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"  [SAVED] Model comparison chart → {save_path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  RESULTS CSV
# ═══════════════════════════════════════════════════════════════════════════════

def save_results_csv(results_df: pd.DataFrame, cv_scores: dict = None,
                     save_path: str = None):
    """
    Save all metrics to a CSV file.

    Parameters
    ----------
    results_df : pd.DataFrame
        Metrics DataFrame.
    cv_scores : dict, optional
        ``{model_name: cv_mean_accuracy}``.
    save_path : str, optional
        Output CSV path.
    """
    if save_path is None:
        save_path = os.path.join(OUTPUT_DIR, "results_summary.csv")

    if cv_scores:
        results_df['CV_Mean_Accuracy'] = results_df['Model'].map(cv_scores)

    cols = ['Model', 'Accuracy', 'Precision', 'Recall', 'F1_Score',
            'AUC_ROC', 'CV_Mean_Accuracy']
    cols = [c for c in cols if c in results_df.columns]

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    results_df[cols].to_csv(save_path, index=False)
    print(f"  [SAVED] Results summary → {save_path}")


# ═══════════════════════════════════════════════════════════════════════════════
# 6.  FALSE POSITIVE / NEGATIVE ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

def false_analysis(y_test, y_pred, X_test_text, model_name: str, n: int = 5):
    """
    Print examples of false positives and false negatives.

    False Positive : Real news (1) predicted as Fake (0)
    False Negative : Fake news (0) predicted as Real (1)

    Parameters
    ----------
    y_test : array-like
        True labels.
    y_pred : array-like
        Predicted labels.
    X_test_text : pd.Series
        Raw combined text (not vectorized) for readable output.
    model_name : str
        Model name for logging.
    n : int
        Number of examples to print (default 5).
    """
    y_test_arr = np.array(y_test)
    y_pred_arr = np.array(y_pred)
    texts = X_test_text.values if hasattr(X_test_text, 'values') else np.array(X_test_text)

    # False Positives: real (1) predicted as fake (0)
    fp_idx = np.where((y_test_arr == 1) & (y_pred_arr == 0))[0]
    # False Negatives: fake (0) predicted as real (1)
    fn_idx = np.where((y_test_arr == 0) & (y_pred_arr == 1))[0]

    print(f"\n{'─'*60}")
    print(f"  FALSE POSITIVE ANALYSIS — {model_name.replace('_', ' ')}")
    print(f"  (Real news classified as Fake)")
    print(f"{'─'*60}")
    for i, idx in enumerate(fp_idx[:n]):
        snippet = texts[idx][:200] + "…" if len(texts[idx]) > 200 else texts[idx]
        print(f"  [{i+1}] {snippet}\n")

    print(f"\n{'─'*60}")
    print(f"  FALSE NEGATIVE ANALYSIS — {model_name.replace('_', ' ')}")
    print(f"  (Fake news classified as Real)")
    print(f"{'─'*60}")
    for i, idx in enumerate(fn_idx[:n]):
        snippet = texts[idx][:200] + "…" if len(texts[idx]) > 200 else texts[idx]
        print(f"  [{i+1}] {snippet}\n")

    print(f"  Total False Positives : {len(fp_idx):,}")
    print(f"  Total False Negatives : {len(fn_idx):,}")


# ═══════════════════════════════════════════════════════════════════════════════
# 7.  FULL EVALUATION PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def evaluate_all(train_results: dict):
    """
    Run the complete evaluation pipeline.

    Parameters
    ----------
    train_results : dict
        Output from ``train.train_all()``.  Must contain keys:
        ``models``, ``X_test``, ``y_test``, ``X_test_text``, ``cv_scores``.

    Returns
    -------
    pd.DataFrame
        The results summary DataFrame.
    """
    models = train_results['models']
    X_test = train_results['X_test']
    y_test = train_results['y_test']
    X_test_text = train_results.get('X_test_text', None)
    cv_scores = train_results.get('cv_scores', {})
    best_name = train_results.get('best_model_name', '')

    all_metrics = []

    print(f"\n{'═'*60}")
    print("  MODEL EVALUATION")
    print(f"{'═'*60}")

    for name, model in models.items():
        print(f"\n── {name.replace('_', ' ')} ──")
        metrics = compute_metrics(model, X_test, y_test, name)
        all_metrics.append(metrics)

        # Print report
        print(f"  Accuracy  : {metrics['Accuracy']:.4f}")
        print(f"  Precision : {metrics['Precision']:.4f}")
        print(f"  Recall    : {metrics['Recall']:.4f}")
        print(f"  F1-Score  : {metrics['F1_Score']:.4f}")
        print(f"  AUC-ROC   : {metrics['AUC_ROC']:.4f}")

        # Classification report
        print(classification_report(
            y_test, metrics['y_pred'],
            target_names=['Fake', 'Real'],
            digits=4
        ))

        # Confusion matrix
        plot_confusion_matrix(y_test, metrics['y_pred'], name)

    # ROC curves
    plot_roc_curves(all_metrics, y_test)

    # Build results DataFrame
    results_df = pd.DataFrame([{
        'Model': m['Model'],
        'Accuracy': m['Accuracy'],
        'Precision': m['Precision'],
        'Recall': m['Recall'],
        'F1_Score': m['F1_Score'],
        'AUC_ROC': m['AUC_ROC'],
    } for m in all_metrics])

    # Model comparison chart
    plot_model_comparison(results_df)

    # Results CSV
    save_results_csv(results_df, cv_scores)

    # False analysis for the best model
    if X_test_text is not None and best_name:
        best_metrics = [m for m in all_metrics if m['Model'] == best_name]
        if best_metrics:
            false_analysis(y_test, best_metrics[0]['y_pred'],
                          X_test_text, best_name)

    print(f"\n{'═'*60}")
    print("  EVALUATION COMPLETE")
    print(f"{'═'*60}")

    # Print summary table
    print("\n" + results_df.to_string(index=False))
    return results_df


# ═══════════════════════════════════════════════════════════════════════════════
# 8.  STANDALONE
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    from src.train import train_all
    print("=" * 60)
    print("  FAKE NEWS DETECTION — EVALUATION")
    print("=" * 60)
    train_results = train_all()
    evaluate_all(train_results)
