"""
preprocess.py — Text Cleaning & Data Preprocessing Pipeline
============================================================
Fake News Detection System
Authors: Hussain Rehan, Minhaj Zaib Khan, Arsalan Ahmed Khan
Subject: Machine Learning (BSCS F23 / 240ML)
Instructor: Dr. Abid Ali — PAF-IAST Mang Haripur

This module provides all text preprocessing utilities:
  - HTML tag removal
  - URL removal
  - Special character / punctuation / digit removal
  - Tokenization, stop-word removal, lemmatization
  - DataFrame-level preprocessing
"""

import os
import re
import random
import numpy as np
import pandas as pd
import nltk
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── Reproducibility ──────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ── Configuration ────────────────────────────────────────────────────────────
# Adjust these paths if your CSVs live elsewhere
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# Alternative data directory (parent "News data" folder)
_ALT_DATA_DIR = os.path.join(os.path.dirname(BASE_DIR), "News data")
_SEARCH_DIRS = [DATA_DIR, _ALT_DATA_DIR]

# Try to find the combined 50k dataset first
COMBINED_CSV = None
for _dir in _SEARCH_DIRS:
    _candidate = os.path.join(_dir, "fake_news_50000.csv")
    if os.path.exists(_candidate):
        COMBINED_CSV = _candidate
        print(f"[CONFIG] Found combined dataset: {COMBINED_CSV}")
        break

# Find Fake.csv and True.csv independently (they may be in different folders)
def _find_csv(filename):
    for _dir in _SEARCH_DIRS:
        path = os.path.join(_dir, filename)
        if os.path.exists(path):
            return path
    return os.path.join(DATA_DIR, filename)  # default fallback

FAKE_CSV = _find_csv("Fake.csv")
TRUE_CSV = _find_csv("True.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

print(f"[CONFIG] Fake.csv → {FAKE_CSV}")
print(f"[CONFIG] True.csv → {TRUE_CSV}")

# ── NLTK Data Download ──────────────────────────────────────────────────────
def download_nltk_data():
    """Download required NLTK data packages if not already present."""
    packages = ['punkt', 'punkt_tab', 'stopwords', 'wordnet',
                'averaged_perceptron_tagger',
                'averaged_perceptron_tagger_eng', 'omw-1.4']
    for pkg in packages:
        nltk.download(pkg, quiet=True)

download_nltk_data()

# ── Global objects (initialised once) ────────────────────────────────────────
STOP_WORDS = set(stopwords.words('english'))
LEMMATIZER = WordNetLemmatizer()


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  TEXT CLEANING
# ═══════════════════════════════════════════════════════════════════════════════

def clean_text(text: str) -> str:
    """
    Apply a full NLP cleaning pipeline to a single text string.

    Steps:
        1. Lowercase
        2. Remove HTML tags  (BeautifulSoup)
        3. Remove URLs       (regex)
        4. Remove special characters, punctuation, digits
        5. Collapse whitespace
        6. Tokenize           (NLTK word_tokenize)
        7. Remove stop words
        8. Lemmatize          (WordNetLemmatizer)
        9. Rejoin tokens

    Parameters
    ----------
    text : str
        Raw input text (title or article body).

    Returns
    -------
    str
        Cleaned text string ready for vectorization.
    """
    if not isinstance(text, str):
        return ""

    # 1. Lowercase
    text = text.lower()

    # 2. Remove HTML tags
    text = BeautifulSoup(text, "lxml").get_text()

    # 3. Remove URLs
    text = re.sub(r'http\S+', '', text)

    # 4. Remove special characters, punctuation, digits
    text = re.sub(r'[^a-z\s]', '', text)

    # 5. Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    # 6. Tokenize
    tokens = word_tokenize(text)

    # 7. Remove stop words
    tokens = [t for t in tokens if t not in STOP_WORDS]

    # 8. Lemmatize
    tokens = [LEMMATIZER.lemmatize(t) for t in tokens]

    # 9. Rejoin
    return ' '.join(tokens)


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  DATA LOADING
# ═══════════════════════════════════════════════════════════════════════════════

def load_data(combined_path: str = COMBINED_CSV,
              fake_path: str = FAKE_CSV,
              true_path: str = TRUE_CSV) -> pd.DataFrame:
    """
    Load the fake news dataset.

    Supports two modes:
      1. Combined CSV  — a single file with columns [title, text, label]
         where label=0 → Fake, label=1 → Real.
      2. Separate CSVs — legacy Fake.csv + True.csv format.

    Parameters
    ----------
    combined_path : str or None
        Path to the combined CSV (fake_news_50000.csv).
    fake_path : str
        Fallback path to the Fake news CSV.
    true_path : str
        Fallback path to the True/Real news CSV.

    Returns
    -------
    pd.DataFrame
        Shuffled DataFrame with at least columns [title, text, label].
        label=0 → Fake,  label=1 → Real.
    """
    # ── Mode 1: Combined CSV (preferred) ───────────────────────────────
    if combined_path and os.path.exists(combined_path):
        print(f"[DATA] Loading combined dataset: {combined_path}")
        df = pd.read_csv(combined_path)
        print(f"       → {len(df):,} rows")

        # Validate required columns
        for col in ['title', 'text', 'label']:
            if col not in df.columns:
                raise ValueError(f"Combined CSV is missing required column: '{col}'")

        # Drop rows with missing text
        df.dropna(subset=['title', 'text'], inplace=True)
        df.reset_index(drop=True, inplace=True)

        # Shuffle
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        print(f"[DATA] Shuffled → {len(df):,} total rows")
        return df

    # ── Mode 2: Separate CSVs (legacy fallback) ───────────────────────
    print("[DATA] Loading Fake.csv ...")
    df_fake = pd.read_csv(fake_path)
    df_fake['label'] = 0
    print(f"       → {len(df_fake):,} rows")

    print("[DATA] Loading True.csv ...")
    df_true = pd.read_csv(true_path)
    df_true['label'] = 1
    print(f"       → {len(df_true):,} rows")

    # Merge
    df = pd.concat([df_fake, df_true], axis=0, ignore_index=True)

    # Shuffle
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    print(f"[DATA] Combined & shuffled → {len(df):,} total rows")

    return df


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  DATAFRAME-LEVEL PREPROCESSING
# ═══════════════════════════════════════════════════════════════════════════════

def preprocess_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply ``clean_text`` to *title* and *text* columns and create a
    *combined* feature that concatenates both.

    Parameters
    ----------
    df : pd.DataFrame
        Raw DataFrame returned by ``load_data()``.

    Returns
    -------
    pd.DataFrame
        Same DataFrame with three new columns:
        ``clean_title``, ``clean_text``, ``combined``.
    """
    total = len(df)
    print(f"[PREPROCESS] Cleaning {total:,} rows — this may take a few minutes …")

    # Clean title
    print("[PREPROCESS] Cleaning titles ...")
    df['clean_title'] = df['title'].apply(clean_text)

    # Clean text
    print("[PREPROCESS] Cleaning article bodies ...")
    df['clean_text'] = df['text'].apply(clean_text)

    # Combined feature
    df['combined'] = df['clean_title'] + ' ' + df['clean_text']

    print("[PREPROCESS] Done.")
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  CLASS DISTRIBUTION
# ═══════════════════════════════════════════════════════════════════════════════

def get_class_distribution(df: pd.DataFrame) -> pd.Series:
    """
    Return and print the class distribution of the dataset.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with a ``label`` column (0=Fake, 1=Real).

    Returns
    -------
    pd.Series
        Value counts for each class.
    """
    dist = df['label'].value_counts().sort_index()
    label_map = {0: 'Fake', 1: 'Real'}
    print("\n╔══════════════════════════════╗")
    print("║     CLASS DISTRIBUTION       ║")
    print("╠══════════════════════════════╣")
    for idx, count in dist.items():
        print(f"║  {label_map[idx]:<6} : {count:>8,}          ║")
    print(f"║  Total  : {dist.sum():>8,}          ║")
    print("╚══════════════════════════════╝\n")
    return dist


def plot_class_distribution(df: pd.DataFrame, save_path: str = None):
    """
    Plot and optionally save a bar chart of class distribution.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with a ``label`` column.
    save_path : str, optional
        If provided, save the figure to this path.
    """
    dist = df['label'].value_counts().sort_index()
    labels = ['Fake (0)', 'Real (1)']
    colors = ['#E74C3C', '#2ECC71']

    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar(labels, dist.values, color=colors, edgecolor='white', linewidth=1.2)
    for bar, val in zip(bars, dist.values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 200,
                f'{val:,}', ha='center', va='bottom', fontweight='bold', fontsize=12)

    ax.set_title('Class Distribution — Fake vs Real News', fontsize=14, fontweight='bold')
    ax.set_ylabel('Number of Articles', fontsize=12)
    ax.set_xlabel('Class', fontsize=12)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150)
        print(f"[PLOT] Class distribution saved → {save_path}")
    plt.close()


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print("  FAKE NEWS DETECTION — DATA PREPROCESSING")
    print("=" * 60)

    # Load
    df = load_data()

    # Class distribution
    get_class_distribution(df)
    plot_class_distribution(df, os.path.join(OUTPUT_DIR, "class_distribution.png"))

    # Preprocess
    df = preprocess_dataframe(df)

    # Show sample
    print("\n── Sample rows ──────────────────────────────────────────")
    print(df[['clean_title', 'clean_text', 'label']].head(3).to_string())
    print(f"\nDataFrame shape : {df.shape}")
    print(f"Columns         : {list(df.columns)}")
