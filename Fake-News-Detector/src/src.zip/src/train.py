"""
train.py — Model Training Pipeline
====================================
Fake News Detection System
Authors: Hussain Rehan, Minhaj Zaib Khan, Arsalan Ahmed Khan
Subject: Machine Learning (BSCS F23 / 240ML)
Instructor: Dr. Abid Ali — PAF-IAST Mang Haripur

Trains 5 classifiers on TF-IDF features:
  1. Passive Aggressive Classifier  (PAC)
  2. Logistic Regression
  3. Multinomial Naive Bayes
  4. Random Forest
  5. Linear SVM

After training, the best model is tuned via GridSearchCV.
All models and the TF-IDF vectorizer are saved to ``models/``.
"""

import os
import sys
import time
import random
import warnings

import numpy as np
import pandas as pd
import joblib
from sklearn.base import clone
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import (train_test_split, StratifiedKFold,
                                     cross_val_score, GridSearchCV)
from sklearn.linear_model import PassiveAggressiveClassifier, LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.calibration import CalibratedClassifierCV

warnings.filterwarnings('ignore')

# ── Reproducibility ──────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "models")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

# Ensure dirs exist
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Add project root so we can import siblings
sys.path.insert(0, BASE_DIR)
from src.preprocess import load_data, preprocess_dataframe, get_class_distribution


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  TF-IDF VECTORIZATION
# ═══════════════════════════════════════════════════════════════════════════════

def build_tfidf_vectorizer() -> TfidfVectorizer:
    """
    Create and return a TfidfVectorizer with project-standard parameters.

    Returns
    -------
    TfidfVectorizer
        Configured but *unfitted* vectorizer.
    """
    return TfidfVectorizer(
        max_features=50_000,
        ngram_range=(1, 2),       # unigrams + bigrams
        sublinear_tf=True,
        min_df=2,
        max_df=0.95,
        strip_accents='unicode',
        token_pattern=r'\b[a-z]{2,}\b'
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  MODEL DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_models() -> dict:
    """
    Return an ordered dict of ``{name: estimator}`` for all five classifiers.

    Notes
    -----
    • PAC is particularly effective for fake-news detection because it
      performs aggressive weight updates on misclassified samples and
      passive (no-change) updates on correctly classified ones — ideal for
      text streams with clear decision boundaries.
    • LinearSVC and PAC lack ``predict_proba``; we wrap them with
      CalibratedClassifierCV so ROC-AUC can be computed.

    Returns
    -------
    dict
        Mapping from model name to scikit-learn estimator.
    """
    models = {
        # Model 1 — Passive Aggressive Classifier
        # PAC is specifically effective for fake news due to online learning:
        # it aggressively updates weights for misclassified samples while
        # remaining passive on correct ones.
        "Passive_Aggressive": CalibratedClassifierCV(
            PassiveAggressiveClassifier(
                max_iter=1000, random_state=42, C=0.1
            ),
            cv=3
        ),

        # Model 2 — Logistic Regression
        "Logistic_Regression": LogisticRegression(
            solver='saga', max_iter=1000, C=1.0, random_state=42
        ),

        # Model 3 — Multinomial Naive Bayes
        "Multinomial_NB": MultinomialNB(alpha=0.1),

        # Model 4 — Random Forest
        "Random_Forest": RandomForestClassifier(
            n_estimators=200, max_depth=None, random_state=42, n_jobs=-1
        ),

        # Model 5 — Linear SVM (wrapped for probability estimates)
        "Linear_SVM": CalibratedClassifierCV(
            LinearSVC(C=1.0, max_iter=2000, random_state=42),
            cv=3
        ),
    }
    return models


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  CROSS-VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

def run_cross_validation(model, X, y, name: str, cv_folds: int = 5) -> float:
    """
    Run stratified k-fold cross-validation and return the mean accuracy.

    Parameters
    ----------
    model : estimator
        A scikit-learn compatible classifier.
    X : sparse matrix
        TF-IDF feature matrix (training portion only).
    y : array-like
        Target labels.
    name : str
        Human-readable model name for logging.
    cv_folds : int
        Number of CV folds (default 5).

    Returns
    -------
    float
        Mean CV accuracy.
    """
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
    scores = cross_val_score(model, X, y, cv=skf, scoring='accuracy', n_jobs=-1)
    mean_acc = scores.mean()
    std_acc = scores.std()
    print(f"  [CV]  {name}: mean={mean_acc:.4f}  std={std_acc:.4f}  "
          f"({cv_folds}-fold StratifiedKFold)")
    return mean_acc


# ═══════════════════════════════════════════════════════════════════════════════
# 4.  HYPERPARAMETER TUNING (best model only)
# ═══════════════════════════════════════════════════════════════════════════════

PARAM_GRIDS = {
    "Passive_Aggressive": {
        "estimator__C": [0.01, 0.1, 0.5, 1.0],
        "estimator__max_iter": [500, 1000, 2000],
    },
    "Logistic_Regression": {
        "C": [0.1, 0.5, 1.0, 5.0],
        "solver": ['saga', 'lbfgs'],
    },
    "Multinomial_NB": {
        "alpha": [0.01, 0.05, 0.1, 0.5, 1.0],
    },
    "Random_Forest": {
        "n_estimators": [100, 200, 300],
        "max_depth": [None, 50, 100],
    },
    "Linear_SVM": {
        "estimator__C": [0.1, 0.5, 1.0, 5.0],
        "estimator__max_iter": [1000, 2000],
    },
}


def tune_best_model(best_name: str, best_model, X_train, y_train):
    """
    Run GridSearchCV on the best-performing model and return the tuned estimator.

    Parameters
    ----------
    best_name : str
        Name of the best model (key in ``PARAM_GRIDS``).
    best_model : estimator
        The best scikit-learn estimator (unfitted copy preferred).
    X_train : sparse matrix
        Training features.
    y_train : array-like
        Training labels.

    Returns
    -------
    estimator
        Refitted estimator with the best hyperparameters found.
    """
    print(f"\n{'═'*60}")
    print(f"  HYPERPARAMETER TUNING — {best_name}")
    print(f"{'═'*60}")

    param_grid = PARAM_GRIDS.get(best_name, {})
    if not param_grid:
        print("  No param grid defined — skipping tuning.")
        return best_model

    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    gs = GridSearchCV(
        best_model, param_grid,
        cv=skf, scoring='accuracy', n_jobs=-1, verbose=1, refit=True
    )
    gs.fit(X_train, y_train)

    print(f"\n  Best params : {gs.best_params_}")
    print(f"  Best CV acc : {gs.best_score_:.4f}")
    return gs.best_estimator_


# ═══════════════════════════════════════════════════════════════════════════════
# 5.  MAIN TRAINING PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def train_all(df: pd.DataFrame = None):
    """
    End-to-end training pipeline.

    1. Load & preprocess data (or accept a pre-processed DataFrame).
    2. TF-IDF vectorize.
    3. Train each model with cross-validation.
    4. Tune the best model via GridSearchCV.
    5. Save all artefacts to disk.

    Parameters
    ----------
    df : pd.DataFrame, optional
        Pre-processed DataFrame.  If ``None``, data will be loaded and
        preprocessed from scratch.

    Returns
    -------
    dict
        ``{ 'models': {name: fitted_model}, 'tfidf': fitted_vectorizer,
            'X_train': …, 'X_test': …, 'y_train': …, 'y_test': …,
            'cv_scores': {name: float}, 'best_model_name': str,
            'df': preprocessed_df }``
    """
    # ── 1. Data ──────────────────────────────────────────────────────────
    if df is None:
        df = load_data()
        get_class_distribution(df)
        df = preprocess_dataframe(df)

    # ── 2. Feature Engineering ───────────────────────────────────────────
    print(f"\n{'═'*60}")
    print("  FEATURE ENGINEERING — TF-IDF")
    print(f"{'═'*60}")

    X = df['combined']
    y = df['label']

    X_train_text, X_test_text, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=42
    )
    print(f"  Train size : {len(X_train_text):,}")
    print(f"  Test  size : {len(X_test_text):,}")

    tfidf = build_tfidf_vectorizer()
    print("  Fitting TF-IDF on training data ...")
    X_train = tfidf.fit_transform(X_train_text)
    X_test = tfidf.transform(X_test_text)
    print(f"  Vocabulary size : {len(tfidf.vocabulary_):,}")
    print(f"  Feature matrix  : {X_train.shape}")

    # Save vectorizer
    tfidf_path = os.path.join(MODEL_DIR, "tfidf_vectorizer.pkl")
    joblib.dump(tfidf, tfidf_path)
    print(f"  [SAVED] TF-IDF vectorizer → {tfidf_path}")

    # ── 3. Train models ─────────────────────────────────────────────────
    models = get_models()
    fitted_models = {}
    cv_scores = {}

    for name, model in models.items():
        print(f"\n{'─'*60}")
        print(f"  Training {name.replace('_', ' ')} ...")
        print(f"{'─'*60}")

        t0 = time.time()

        # Cross-validation (use sklearn clone for safe deep-copy)
        cv_mean = run_cross_validation(
            clone(model),
            X_train, y_train, name
        )
        cv_scores[name] = cv_mean

        # Full training-set fit
        model.fit(X_train, y_train)
        elapsed = time.time() - t0
        print(f"  Training time : {elapsed:.1f}s")

        fitted_models[name] = model

        # Save individual model
        model_path = os.path.join(MODEL_DIR, f"{name}.pkl")
        joblib.dump(model, model_path)
        print(f"  [SAVED] {name} → {model_path}")

    print(f"\n{'─'*60}")
    print("  Done training all models.")
    print(f"{'─'*60}\n")

    # ── 4. Determine best & tune ─────────────────────────────────────────
    best_name = max(cv_scores, key=cv_scores.get)
    print(f"  ★ Best model by CV accuracy: {best_name} ({cv_scores[best_name]:.4f})")

    # Clone a fresh model for tuning
    fresh_models = get_models()
    tuned_model = tune_best_model(best_name, fresh_models[best_name],
                                  X_train, y_train)
    fitted_models[best_name] = tuned_model

    # Save best model
    best_path = os.path.join(MODEL_DIR, "best_model.pkl")
    joblib.dump(tuned_model, best_path)
    print(f"  [SAVED] Best model (tuned) → {best_path}")

    # Save best model name
    meta_path = os.path.join(MODEL_DIR, "model_meta.txt")
    with open(meta_path, 'w') as f:
        f.write(best_name)
    print(f"  [SAVED] Best-model name    → {meta_path}")

    # ── 5. Return everything for evaluate.py ─────────────────────────────
    return {
        'models': fitted_models,
        'tfidf': tfidf,
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
        'X_test_text': X_test_text,
        'cv_scores': cv_scores,
        'best_model_name': best_name,
        'df': df,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 6.  STANDALONE
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print("  FAKE NEWS DETECTION — MODEL TRAINING")
    print("=" * 60)
    results = train_all()
    print("\n✔ Training complete.  Models saved in:", MODEL_DIR)
