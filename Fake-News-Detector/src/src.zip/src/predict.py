"""
predict.py — Single-Article Prediction Function
=================================================
Fake News Detection System
Authors: Hussain Rehan, Minhaj Zaib Khan, Arsalan Ahmed Khan
Subject: Machine Learning (BSCS F23 / 240ML)
Instructor: Dr. Abid Ali — PAF-IAST Mang Haripur

Provides ``predict_article(title, text)`` which:
  1. Cleans & combines input text
  2. Loads saved TF-IDF vectorizer + best model
  3. Returns label, confidence, and key words
"""

import os
import sys
import random

import numpy as np
import joblib

# ── Reproducibility ──────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "models")

sys.path.insert(0, BASE_DIR)
from src.preprocess import clean_text

# ── Cached model objects ─────────────────────────────────────────────────────
_model_cache = {}


def _load_artefacts():
    """
    Load the TF-IDF vectorizer, best model, and model name from disk.
    Results are cached in ``_model_cache`` so subsequent calls are instant.

    Returns
    -------
    tuple
        (vectorizer, model, model_name)

    Raises
    ------
    FileNotFoundError
        If model files are missing (training has not been run).
    """
    if 'model' in _model_cache:
        return _model_cache['tfidf'], _model_cache['model'], _model_cache['name']

    tfidf_path = os.path.join(MODEL_DIR, "tfidf_vectorizer.pkl")
    best_path = os.path.join(MODEL_DIR, "best_model.pkl")
    meta_path = os.path.join(MODEL_DIR, "model_meta.txt")

    if not os.path.exists(tfidf_path):
        raise FileNotFoundError(
            f"TF-IDF vectorizer not found at {tfidf_path}. "
            "Please run training first (python run_all.py)."
        )
    if not os.path.exists(best_path):
        raise FileNotFoundError(
            f"Best model not found at {best_path}. "
            "Please run training first (python run_all.py)."
        )

    tfidf = joblib.load(tfidf_path)
    model = joblib.load(best_path)

    model_name = "Unknown"
    if os.path.exists(meta_path):
        with open(meta_path, 'r') as f:
            model_name = f.read().strip()

    _model_cache['tfidf'] = tfidf
    _model_cache['model'] = model
    _model_cache['name'] = model_name

    return tfidf, model, model_name


def predict_article(title: str, text: str) -> dict:
    """
    Predict whether a news article is **FAKE** or **REAL**.

    Parameters
    ----------
    title : str
        Headline / title of the article.
    text : str
        Full body text of the article.

    Returns
    -------
    dict
        {
            "label"          : "FAKE" or "REAL",
            "confidence"     : float  (0.0 – 1.0),
            "confidence_pct" : str    e.g. "87.3%",
            "key_words"      : list of (word, tfidf_weight) tuples,
            "model_used"     : str    name of the classifier
        }

    Examples
    --------
    >>> result = predict_article("Breaking News", "The president said...")
    >>> result['label']
    'REAL'
    """
    tfidf, model, model_name = _load_artefacts()

    # 1. Combine
    combined = (title or "") + " " + (text or "")

    # 2. Clean
    cleaned = clean_text(combined)

    # 3-5. Vectorize
    X = tfidf.transform([cleaned])

    # 6. Predict
    prediction = model.predict(X)[0]  # 0=Fake, 1=Real
    label = "REAL" if prediction == 1 else "FAKE"

    # 7. Confidence score
    if hasattr(model, 'predict_proba'):
        proba = model.predict_proba(X)[0]
        confidence = float(np.max(proba))
    elif hasattr(model, 'decision_function'):
        score = model.decision_function(X)[0]
        confidence = float(1 / (1 + np.exp(-score)))  # sigmoid
        if prediction == 0:
            confidence = 1 - confidence
    else:
        confidence = 1.0

    confidence_pct = f"{confidence * 100:.1f}%"

    # 8. Key words by TF-IDF weight in this document
    feature_names = np.array(tfidf.get_feature_names_out())
    tfidf_weights = X.toarray().flatten()
    nonzero_idx = tfidf_weights.nonzero()[0]

    if len(nonzero_idx) > 0:
        top_indices = nonzero_idx[np.argsort(tfidf_weights[nonzero_idx])[::-1][:10]]
        key_words = [
            {"word": feature_names[i], "weight": round(float(tfidf_weights[i]), 4)}
            for i in top_indices
        ]
    else:
        key_words = []

    return {
        "label": label,
        "confidence": round(confidence, 4),
        "confidence_pct": confidence_pct,
        "key_words": key_words,
        "model_used": model_name.replace('_', ' '),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 60)
    print("  FAKE NEWS DETECTION — PREDICTION TEST")
    print("=" * 60)

    # Example fake article
    fake_title = "BREAKING: Exposed government conspiracy to hide aliens"
    fake_text = ("Anonymous sources have revealed a massive cover-up by "
                 "government officials to hide evidence of extraterrestrial "
                 "life found in a secret underground facility.")

    # Example real article
    real_title = "Federal Reserve raises interest rates by 0.25%"
    real_text = ("The Federal Reserve announced on Wednesday that it would "
                 "raise the benchmark interest rate by a quarter of a "
                 "percentage point, citing continued economic growth and "
                 "low unemployment figures.")

    for tag, title, text in [("FAKE EXAMPLE", fake_title, fake_text),
                              ("REAL EXAMPLE", real_title, real_text)]:
        print(f"\n── {tag} ──")
        result = predict_article(title, text)
        print(f"  Label      : {result['label']}")
        print(f"  Confidence : {result['confidence_pct']}")
        print(f"  Model      : {result['model_used']}")
        print(f"  Key words  :")
        for kw in result['key_words'][:5]:
            print(f"    • {kw['word']} ({kw['weight']:.4f})")
