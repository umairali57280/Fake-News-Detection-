"""
wordcloud_gen.py — Word Cloud & Top-Feature Generation
=======================================================
Fake News Detection System
Authors: Hussain Rehan, Minhaj Zaib Khan, Arsalan Ahmed Khan
Subject: Machine Learning (BSCS F23 / 240ML)
Instructor: Dr. Abid Ali — PAF-IAST Mang Haripur

Generates:
  • Word cloud for Fake news articles
  • Word cloud for Real news articles
  • Top 20 most discriminating TF-IDF features per class
"""

import os
import sys
import random

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import joblib

# ── Reproducibility ──────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
WC_DIR = os.path.join(OUTPUT_DIR, "wordclouds")
MODEL_DIR = os.path.join(BASE_DIR, "models")

os.makedirs(WC_DIR, exist_ok=True)

sys.path.insert(0, BASE_DIR)


def generate_wordcloud(text: str, title: str, colormap: str,
                       save_path: str):
    """
    Generate and save a word cloud image.

    Parameters
    ----------
    text : str
        Space-joined cleaned text corpus.
    title : str
        Plot title.
    colormap : str
        Matplotlib colormap name (e.g. ``'Reds'``, ``'Greens'``).
    save_path : str
        File path for the saved PNG.
    """
    wc = WordCloud(
        width=800,
        height=400,
        background_color='black',
        colormap=colormap,
        max_words=200,
        random_state=42,
        contour_width=1,
        contour_color='white',
        collocations=False,
    ).generate(text)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.imshow(wc, interpolation='bilinear')
    ax.set_title(title, fontsize=16, fontweight='bold', color='white',
                 pad=10)
    ax.axis('off')
    fig.patch.set_facecolor('black')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, facecolor='black', bbox_inches='tight')
    plt.close()
    print(f"  [SAVED] Word cloud → {save_path}")


def print_top_tfidf_features(tfidf_matrix, feature_names, labels,
                              n: int = 20):
    """
    Print the top *n* most discriminating TF-IDF features for each class.

    Discrimination is measured by comparing mean TF-IDF scores for
    Fake vs Real articles.

    Parameters
    ----------
    tfidf_matrix : sparse matrix
        TF-IDF feature matrix (training set).
    feature_names : array-like
        Feature names from the vectorizer.
    labels : array-like
        Class labels (0=Fake, 1=Real).
    n : int
        Number of top features to display (default 20).
    """
    labels = np.array(labels)

    fake_mean = np.asarray(tfidf_matrix[labels == 0].mean(axis=0)).flatten()
    real_mean = np.asarray(tfidf_matrix[labels == 1].mean(axis=0)).flatten()

    # Difference: positive → more Fake, negative → more Real
    diff = fake_mean - real_mean

    top_fake_idx = np.argsort(diff)[::-1][:n]
    top_real_idx = np.argsort(diff)[:n]

    print(f"\n{'═'*60}")
    print(f"  TOP {n} MOST DISCRIMINATING TF-IDF FEATURES")
    print(f"{'═'*60}")

    print(f"\n  ── Indicative of FAKE news ──")
    for rank, idx in enumerate(top_fake_idx, 1):
        print(f"  {rank:>3}. {feature_names[idx]:<25} "
              f"(Δ = {diff[idx]:+.4f}  |  "
              f"fake={fake_mean[idx]:.4f}  real={real_mean[idx]:.4f})")

    print(f"\n  ── Indicative of REAL news ──")
    for rank, idx in enumerate(top_real_idx, 1):
        print(f"  {rank:>3}. {feature_names[idx]:<25} "
              f"(Δ = {diff[idx]:+.4f}  |  "
              f"fake={fake_mean[idx]:.4f}  real={real_mean[idx]:.4f})")


def generate_all_wordclouds(df: pd.DataFrame = None, tfidf_matrix=None,
                            feature_names=None, labels=None):
    """
    Generate word clouds for both classes and print top TF-IDF features.

    Parameters
    ----------
    df : pd.DataFrame, optional
        Preprocessed DataFrame with ``combined`` and ``label`` columns.
    tfidf_matrix : sparse matrix, optional
        Training TF-IDF matrix (for top-feature analysis).
    feature_names : array-like, optional
        Feature names from the vectorizer.
    labels : array-like, optional
        Training labels (for top-feature analysis).
    """
    print(f"\n{'═'*60}")
    print("  WORD CLOUD GENERATION")
    print(f"{'═'*60}")

    if df is not None:
        # Fake news word cloud
        fake_text = ' '.join(df[df['label'] == 0]['combined'].dropna().tolist())
        real_text = ' '.join(df[df['label'] == 1]['combined'].dropna().tolist())

        if fake_text.strip():
            generate_wordcloud(
                fake_text,
                title='Word Cloud — FAKE News',
                colormap='Reds',
                save_path=os.path.join(WC_DIR, 'fake_wordcloud.png')
            )
        else:
            print("  [WARN] No fake-class text available for word cloud.")

        if real_text.strip():
            generate_wordcloud(
                real_text,
                title='Word Cloud — REAL News',
                colormap='Greens',
                save_path=os.path.join(WC_DIR, 'real_wordcloud.png')
            )
        else:
            print("  [WARN] No real-class text available for word cloud.")

    # Top TF-IDF features
    if tfidf_matrix is not None and feature_names is not None and labels is not None:
        print_top_tfidf_features(tfidf_matrix, feature_names, labels)
    elif df is not None:
        # Try loading saved vectorizer
        tfidf_path = os.path.join(MODEL_DIR, "tfidf_vectorizer.pkl")
        if os.path.exists(tfidf_path):
            tfidf = joblib.load(tfidf_path)
            feat_names = tfidf.get_feature_names_out()
            mat = tfidf.transform(df['combined'].fillna(''))
            print_top_tfidf_features(mat, feat_names, df['label'].values)

    print(f"\n{'═'*60}")
    print("  WORD CLOUDS DONE")
    print(f"{'═'*60}")


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    from src.preprocess import load_data, preprocess_dataframe

    print("=" * 60)
    print("  FAKE NEWS DETECTION — WORD CLOUDS")
    print("=" * 60)

    df = load_data()
    df = preprocess_dataframe(df)
    generate_all_wordclouds(df=df)
